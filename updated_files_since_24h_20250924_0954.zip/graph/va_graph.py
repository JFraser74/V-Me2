"""Guarded ReAct adapter for V-Me2.

Provides a small, defensive wrapper around an optional LangGraph ReAct agent.
If langgraph/langchain-openai or OpenAI credentials are missing the module
falls back to a simple echo responder so tests and local development work.

Features:
- GuardedChatOpenAI wrapper that filters illegal ToolMessage sequences before
  calling the LLM (prevents OpenAI 400s when role='tool' appears out of flow).
- Optional tools are enabled via AGENT_TOOLS_ENABLED env var.
"""

from __future__ import annotations
import os
from typing import Any, Dict, List, TypedDict, TYPE_CHECKING, Optional, cast

if TYPE_CHECKING:
    # Types only for static analysis
    from langgraph.prebuilt import create_react_agent  # type: ignore
    from langchain_openai import ChatOpenAI  # type: ignore
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage  # type: ignore
    from langgraph.graph import MessagesState  # type: ignore


try:
    from langgraph.prebuilt import create_react_agent
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage
    from langgraph.graph import MessagesState
    _LG_OK = True
except Exception:
    _LG_OK = False


try:
    from tools.codespace import (
        ls_tool,
        read_file_tool,
        write_file_tool,
        git_status_tool,
        git_diff_tool,
        git_commit_tool,
    )
    from tools.supabase_tools import sb_select_tool, sb_upsert_tool
    _TOOLS_OK = True
except Exception:
    _TOOLS_OK = False


class AgentState(TypedDict):
    session_id: str
    # Keep a plain runtime-friendly type for messages; editors can still
    # use the more precise MessagesState when TYPE_CHECKING is enabled.
    messages: List[Dict[str, Any]]
    remaining_steps: int


def _filter_tool_sequence(messages: List[Any]) -> List[Any]:
    """Ensure any ToolMessage is immediately preceded by an AIMessage with tool_calls.
    If not, drop that ToolMessage to avoid OpenAI 400s.
    """
    if not messages:
        return messages
    out: List[Any] = []
    prev_ai_had_tool_calls = False
    for m in messages:
        try:
            # Only check isinstance if langgraph types are available
            if _LG_OK and isinstance(m, AIMessage):
                prev_ai_had_tool_calls = bool(getattr(m, "tool_calls", None))
                out.append(m)
            elif _LG_OK and isinstance(m, ToolMessage):
                # Keep only if it follows an AI tool call
                if prev_ai_had_tool_calls:
                    out.append(m)
                # do not flip the flag
            else:
                out.append(m)
                prev_ai_had_tool_calls = False
        except Exception:
            out.append(m)
            prev_ai_had_tool_calls = False
    return out


if _LG_OK:
    # When langchain_openai.ChatOpenAI is available, subclass it so the
    # resulting object supports methods like bind_tools expected by langgraph.
    class GuardedChatOpenAI(ChatOpenAI):
        """ChatOpenAI subclass that filters tool-message sequences before invoke."""

        def invoke(self, input, config=None, **kwargs):
            try:
                if isinstance(input, dict) and "messages" in input:
                    input = dict(input)
                    msgs = _filter_tool_sequence(input["messages"])
                    # If filtering removed all messages, inject a minimal system message
                    if not msgs:
                        msgs = [SystemMessage(content="You are a helpful assistant.")]
                    input["messages"] = msgs
                elif isinstance(input, list):
                    msgs = _filter_tool_sequence(input)
                    if not msgs:
                        msgs = [SystemMessage(content="You are a helpful assistant.")]
                    input = msgs
            except Exception:
                pass
            # cast to Any to satisfy langchain/langgraph runtime typing
            return super().invoke(cast(Any, input), config=cast(Any, config), **kwargs)
else:
    # Defensive fallback when ChatOpenAI isn't importable
    class GuardedChatOpenAI:
        def __init__(self, *args, **kwargs):
            self._inner = None

        def invoke(self, input, config=None, **kwargs):
            try:
                if isinstance(input, dict) and "messages" in input:
                    input = dict(input)
                    msgs = _filter_tool_sequence(input["messages"])
                    if not msgs:
                        # Fallback: ensure we don't call an empty array — use a minimal placeholder
                        msgs = [{"role": "system", "content": "You are a helpful assistant."}]
                    input["messages"] = msgs
                elif isinstance(input, list):
                    msgs = _filter_tool_sequence(input)
                    if not msgs:
                        msgs = [{"role": "system", "content": "You are a helpful assistant."}]
                    input = msgs
            except Exception:
                pass
            return {"messages": input}


def _build_graph():
    """Build a ReAct agent graph when deps + OPENAI_API_KEY are available."""
    if not (_LG_OK and os.getenv("OPENAI_API_KEY")):
        return None

    tools: List[Any] = []
    # Enable/disable tool usage via env (AGENT_TOOLS_ENABLED=0 to disable)
    _tools_enabled = os.getenv("AGENT_TOOLS_ENABLED", "1") not in ("0", "false", "False")
    if _TOOLS_OK and _tools_enabled:
        tools = [
            ls_tool,
            read_file_tool,
            write_file_tool,
            git_status_tool,
            git_diff_tool,
            git_commit_tool,
            sb_select_tool,
            sb_upsert_tool,
        ]

    # Use the guarded LLM to avoid tool-role payload rejections
    llm = GuardedChatOpenAI(model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=0)
    return create_react_agent(cast(Any, llm), tools, state_schema=AgentState)


class _Wrapper:
    def __init__(self):
        self._graph = _build_graph()

    def _to_lc_messages(self, items: List[Dict[str, Any]]):
        if not _LG_OK:
            return items
        out: List[Any] = []
        for m in items:
            role = m.get("role", "user")
            content = m.get("content", "")
            # IMPORTANT: never replay persisted 'tool' messages (they lack tool_call_id context)
            if role == "tool":
                continue
            if role == "user":
                out.append(HumanMessage(content=content))
            elif role == "assistant":
                out.append(AIMessage(content=content))
            else:
                out.append(SystemMessage(content=content))
        return out

    def invoke(self, state: Dict[str, Any], config: Dict[str, Any] | None = None) -> Dict[str, Any]:
        if self._graph is None:
            msgs = state.get("messages", [])
            last = msgs[-1]["content"] if msgs else ""
            return {"last_text": f"Echo: {last}", "session_id": state.get("session_id", "")}
        msgs = [m for m in state.get("messages", []) if m.get("role") != "tool"]

        # cast config to Any to satisfy runtime/lint differences for RunnableConfig
        res = self._graph.invoke({"session_id": state.get("session_id", ""), "messages": self._to_lc_messages(msgs)}, config=cast(Any, config))

        last_text = ""
        tool_events: List[Dict[str, Any]] = []
        try:
            call_inputs: Dict[str, Dict[str, Any]] = {}
            for m in res.get("messages", []) or []:
                if _LG_OK and isinstance(m, AIMessage) and getattr(m, "tool_calls", None):
                    for tc in m.tool_calls:
                        tcid: Optional[str] = tc.get("id")
                        if not tcid:
                            continue
                        call_inputs[tcid] = {"tool_name": tc.get("name"), "input_json": tc.get("args")}

            for m in reversed(res.get("messages", []) or []):
                if _LG_OK and isinstance(m, AIMessage):
                    last_text = getattr(m, "content", "")
                    break

            for m in res.get("messages", []) or []:
                if _LG_OK and isinstance(m, ToolMessage):
                    tcid = getattr(m, "tool_call_id", None)
                    entry: Dict[str, Any] = {"tool_name": None, "input_json": None, "output_json": getattr(m, "content", None)}
                    if tcid and tcid in call_inputs:
                        entry["tool_name"] = call_inputs[tcid].get("tool_name")
                        entry["input_json"] = call_inputs[tcid].get("input_json")
                    tool_events.append(entry)
        except Exception:
            msgs = state.get("messages", [])
            last = msgs[-1]["content"] if msgs else ""
            last_text = f"Echo: {last}"

        return {"last_text": last_text, "session_id": state.get("session_id", ""), "tool_events": tool_events}


_singleton = _Wrapper()


def get_graph():
    return _singleton

