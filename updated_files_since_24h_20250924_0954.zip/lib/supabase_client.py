import os
from typing import Optional, Union
from supabase import create_client, Client

_sb: Optional[Client] = None


def _client() -> Optional[Client]:
    """Create or return a cached Supabase client. Returns None if credentials are missing.

    Environment variables checked:
      - SUPABASE_URL
      - SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY
    """
    global _sb
    if _sb is not None:
        return _sb
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_ANON_KEY")
    if not url or not key:
        return None
    try:
        _sb = create_client(url, key)
    except Exception:
        _sb = None
    return _sb


def create_session(label: Optional[str] = None) -> Optional[int]:
    sb = _client()
    if not sb:
        return None
    try:
        res = sb.table("va_sessions").insert({"label": label}).execute()
        return res.data[0]["id"] if res.data else None
    except Exception:
        return None


def safe_log_message(session_id: Union[int, str, None], role: str, content: str):
    sb = _client()
    if not sb:
        return
    try:
        sid = session_id
        if isinstance(sid, str):
            try:
                sid = int(sid)
            except ValueError:
                sid = None
        sb.table("va_messages").insert({
            "session_id": sid,
            "role": role,
            "content": content,
        }).execute()
    except Exception:
        pass


def safe_log_tool_event(session_id: Union[int, str, None], tool_name: str, input_json: dict | None, output_json: dict | str | None):
    sb = _client()
    if not sb:
        return
    try:
        sid = session_id
        if isinstance(sid, str):
            try:
                sid = int(sid)
            except ValueError:
                sid = None
        payload = {
            "session_id": sid,
            "tool_name": tool_name,
            "input_json": input_json,
            "output_json": output_json,
        }
        sb.table("va_tool_events").insert(payload).execute()
    except Exception:
        pass


def select_tool_events(session_id: Union[int, str], limit: int = 10):
    sb = _client()
    if not sb:
        return []
    try:
        sid = int(session_id) if isinstance(session_id, str) else session_id
        res = sb.table("va_tool_events").select("*").eq("session_id", sid).order("created_at", desc=True).limit(limit).execute()
        return res.data or []
    except Exception:
        return []
